#include <stdio.h>
#include <math.h>
unsigned char getBit(unsigned char, int);
unsigned char setBit(unsigned char, int);
unsigned char clearBit(unsigned char, int);
void printBits(unsigned char);

int main() {

  unsigned char a = 'A';

  unsigned char arr[2][3][4] = {
                                  {
                                    {62,138,241,129},
                                    {8,221,163,159},
                                    {91,158,169,150}
                                  },
                                  {
                                    {15,138,251,198},
                                    {14,211,161,158},
                                    {77,204,188,217}
                                  }
                                };

  int i, j, k;

  printBits(a);
  a = setBit(a, 2);
  a = setBit(a, 3);
  printBits(a);
  a = clearBit(a, 2);
  printBits(a);
  printf("\n");

  /* implement question 4 here */
  long unsigned int size = sizeof(arr)/sizeof(arr[0]);
  long unsigned int element = sizeof(arr[0])/sizeof(char);
  long unsigned int num_per_row = element/sizeof(arr[0][0]);
  int counter = 0;
  for (int i = 0; i < size; i++){
    for (int j = 0; j < num_per_row; j++){
      for (int k = 0; k < sizeof(arr[0][0]); k++){
        arr[i][j][k] = clearBit(arr[i][j][k], 6);
        arr[i][j][k] = setBit(arr[i][j][k], 3);
        counter++;
        printBits(arr[i][j][k]);
      }
    }
  }
  
  return 0;
}


unsigned char getBit(unsigned char c, int n) {
  unsigned char answer = 1 << n;
  answer = answer & c;
  return answer; 

}

unsigned char setBit(unsigned char c, int n) {
  unsigned char answer  = 1 << n;
  answer = answer | c;
  return answer;
}

unsigned char clearBit(unsigned char c, int n) {
  unsigned char answer = 1 << n;
  answer = (~answer) & c;
  return answer;
}

void printBits(unsigned char c) {
  for (int i =7; i >= 0; i--){
    if((int) (c/pow(2,i)) > 0){
      printf("1");
      c = c - pow(2,i);
    }else{
      printf("0");
    }
  }
  printf("\n");
}

